﻿using System;

public class Engine
{
    private CommandInterpreter commandInterpreter;

    public Engine()
    {
        this.commandInterpreter = new CommandInterpreter();
    }

    public void Run()
    {
        var cmdArgs = Console.ReadLine().Split();

        while (cmdArgs[0] != "END")
        {
            this.commandInterpreter.InterpretCommand(cmdArgs);
            cmdArgs = Console.ReadLine().Split();
        }
    }
}