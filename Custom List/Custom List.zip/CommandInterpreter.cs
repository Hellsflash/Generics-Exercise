﻿using System;

public class CommandInterpreter
{
    private IMyList<string> myList;

    public CommandInterpreter()
    {
        myList = new MyList<string>();
    }

    public void InterpretCommand(string[] cmdArgs)
    {
        var command = cmdArgs[0];
        string element;

        switch (command)
        {
            case "Add":
                element = cmdArgs[1];
                this.myList.Add(element);
                break;

            case "Remove":
                var index = int.Parse(cmdArgs[1]);
                this.myList.Remove(index);
                break;

            case "Contains":
                element = cmdArgs[1];
                Console.WriteLine(this.myList.Contains(element));
                break;

            case "Swap":
                var firstIndex = int.Parse(cmdArgs[1]);
                var secondIndex = int.Parse(cmdArgs[2]);
                this.myList.Swap(firstIndex, secondIndex);
                break;

            case "Greater":
                element = cmdArgs[1];
                Console.WriteLine(this.myList.CountGreaterThan(element));
                break;

            case "Max":
                Console.WriteLine(this.myList.Max());
                break;

            case "Min":
                Console.WriteLine(this.myList.Min());
                break;

            case "Print":
                Console.WriteLine(this.myList);
                break;

            default:
                break;
        }
    }
}